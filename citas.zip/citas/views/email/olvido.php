<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <title>Recuperación de clave</title>
</head>
<body>
<div style="width: 640px; font-family: Arial, Helvetica, sans-serif; font-size: 11px;">
  <h1>Recuperación de clave</h1>
  <div align="left">
			<p>Estimado(a)  %nombres%  %apellidos%<p>
			<p>Entre entre a este link para poder cambiar su clave:
			 Link : %ruta%       <br>
			<a target="_blank" href="%ruta%">Link</a>
			Saludos pee !!</p>
  </div>
  
</div>
</body>
</html>
