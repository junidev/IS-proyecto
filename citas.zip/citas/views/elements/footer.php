<div class="row-fluid">
  <div id="footer" class="span12"> 2017 &copy; Admin by LoQuiFru  </div>
</div>